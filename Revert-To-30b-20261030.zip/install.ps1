<#
  Installs the pension "no question when the numbers already agree" fix.
  It only copies files; it never deletes anything.
  Run in PowerShell:  .\install.ps1
#>
$ErrorActionPreference = "Stop"
$Project = "C:\Users\User\Downloads\tr-pension-merge-branch-20261026"
if (-not (Test-Path $Project)) { Write-Host "Project folder not found: $Project" -ForegroundColor Red; exit 1 }
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Source = Join-Path $Here "files"
$Backup = Join-Path $Here "backup-before-fix"
if (-not (Test-Path $Source)) { Write-Host "files folder missing next to install.ps1" -ForegroundColor Red; exit 1 }
Write-Host "Project : $Project"
$copied = 0
Get-ChildItem -Path $Source -Recurse -File | ForEach-Object {
  $relative = $_.FullName.Substring($Source.Length).TrimStart('\')
  $target = Join-Path $Project $relative
  if ($_.FullName -eq $target) { Write-Host "skip (already in place) $relative" -ForegroundColor DarkGray; return }
  if (Test-Path $target) {
    $keep = Join-Path $Backup $relative
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $keep) | Out-Null
    Copy-Item -Path $target -Destination $keep -Force
  }
  $dir = Split-Path -Parent $target
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  Copy-Item -Path $_.FullName -Destination $target -Force
  Write-Host "ok   $relative" -ForegroundColor Green
  $script:copied++
}
Write-Host ""
Write-Host "Files copied: $copied"
Write-Host "Next, in the project folder:" -ForegroundColor Cyan
Write-Host "  .\node_modules\.bin\tsc --noEmit"
Write-Host "  node --test scripts\verify-pension-review-policy.cjs"
Write-Host "  node --test scripts\verify-pension-statement.cjs"
Write-Host "Then restart the app:  .\electron-connect\start-live.ps1"
